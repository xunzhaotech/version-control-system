module.exports = {
  plugins: [
      require('precss'),
      require('autoprefixer')
  ]
}