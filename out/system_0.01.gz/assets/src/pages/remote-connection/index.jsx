import React, { Component } from 'react';
import { Table, Button } from 'antd';

import './index.less';

class View extends Component {
  constructor(props) {
    super(props);
    this.state = {

    };
  }
  render() {

    return (
      <div className='remote-connection'>
      </div>
    )
  }
}

export default View;
