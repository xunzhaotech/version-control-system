export default {
  getAppList: '/system/api/app/list',
  getServerInfo: '/system/api/server/info',
  //获取日志
  getLogInfo: '/system/api/server/log',
  //获取机器内存信息
  getMacheine: '/system/api/server/RAM'
}
