import React from 'react';
import { Icon } from 'antd';
import './index.less';

class Scroll extends React.Component {
  constructor() {
    super();
    this.state = {
    };
  }

  render() {
    
    return (
      <div>
        
      </div>
    );
  }
}

export default Scroll;