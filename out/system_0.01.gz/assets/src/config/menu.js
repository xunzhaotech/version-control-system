export default [
  {
    title: '数据统计',
    key: 'view',
    icon: 'area-chart'
  },
  {
    title: '应用列表',
    key: 'app-list',
    icon: 'deployment-unit'
  },{
    title: '应用部署',
    key: 'app-deploy',
    icon: 'appstore'
  },{
    title: '日志服务',
    key: 'log-server',
    icon: 'file-text'
  }
  // ,{
  //   title: '远程连接',
  //   key: 'remote-connection',
  //   icon: 'link'
  // }
]