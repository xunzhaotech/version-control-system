import Router from './router';
import ReactDOM from 'react-dom';
import React from 'react';
import './index.less';

ReactDOM.render(<Router />, document.getElementById('root'));