const mongoose = require('../tool/mongodb');

//注册
exports.reg = (req, url) => {
  let params = req.body;
  
}